<?php
/** @deprecated Use App\Models\InvestorsTargetPreferences */
namespace App\Models;
class_alias(InvestorsTargetPreferences::class, 'App\Models\BuyersTargetPreferences');
