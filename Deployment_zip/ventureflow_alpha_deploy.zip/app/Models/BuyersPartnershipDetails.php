<?php
/** @deprecated Use App\Models\InvestorsPartnershipDetails */
namespace App\Models;
class_alias(InvestorsPartnershipDetails::class, 'App\Models\BuyersPartnershipDetails');
