<?php
/** @deprecated Use App\Models\InvestorsFinancialDetails */
namespace App\Models;
class_alias(InvestorsFinancialDetails::class, 'App\Models\BuyersFinancialDetails');
