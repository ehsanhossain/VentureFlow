<?php
/**
 * @deprecated Use App\Models\Target instead.
 * This file is kept as a backward-compatibility shim.
 */
namespace App\Models;
class_alias(Target::class, 'App\Models\Seller');
