<?php

/**
 * Copyright (c) 2026 VentureFlow. All rights reserved.
 * Unauthorized copying, modification, or distribution of this file is strictly prohibited.
 */

/**
 * @deprecated Use App\Http\Controllers\TargetController instead.
 * This file is kept as a backward-compatibility shim only.
 */
namespace App\Http\Controllers;

class SellerController extends TargetController {}
