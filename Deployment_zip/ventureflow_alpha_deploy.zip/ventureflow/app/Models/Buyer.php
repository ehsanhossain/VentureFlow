<?php
/**
 * @deprecated Use App\Models\Investor instead.
 * This file is kept as a backward-compatibility shim.
 */
namespace App\Models;
class_alias(Investor::class, 'App\Models\Buyer');
