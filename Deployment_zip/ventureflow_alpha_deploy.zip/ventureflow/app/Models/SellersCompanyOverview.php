<?php
/** @deprecated Use App\Models\TargetsCompanyOverview */
namespace App\Models;
class_alias(TargetsCompanyOverview::class, 'App\Models\SellersCompanyOverview');
