<?php
/** @deprecated Use App\Models\TargetsFinancialDetail */
namespace App\Models;
class_alias(TargetsFinancialDetail::class, 'App\Models\SellersFinancialDetail');
