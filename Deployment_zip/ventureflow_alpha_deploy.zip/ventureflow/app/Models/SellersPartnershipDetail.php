<?php
/** @deprecated Use App\Models\TargetsPartnershipDetail */
namespace App\Models;
class_alias(TargetsPartnershipDetail::class, 'App\Models\SellersPartnershipDetail');
