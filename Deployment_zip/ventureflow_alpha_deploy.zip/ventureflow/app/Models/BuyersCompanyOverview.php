<?php
/** @deprecated Use App\Models\InvestorsCompanyOverview */
namespace App\Models;
class_alias(InvestorsCompanyOverview::class, 'App\Models\BuyersCompanyOverview');
